import os

class Config:
    SECRET_KEY = "databroker229_secret_key_change_en_production"
    SQLALCHEMY_DATABASE_URI = "sqlite:///databroker229.db"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = "uploads"
    MAX_CONTENT_LENGTH = 5 * 1024 * 1024

    # Marge bénéficiaire (40%)
    MARGE = 0.40

    # Email
    EMAIL_EXPEDITEUR  = "jeanjacquesaguin30@gmail.com"
    EMAIL_MOT_DE_PASSE = "MOT_DE_PASSE_APP_GMAIL"  # On configurera ça ensemble
    EMAIL_NOM         = "DataBroker 229"

    # Contacts
    WHATSAPP          = "+22961976712"
    TELEPHONE         = "+2290155256871"

    # Kkiapay (mode sandbox)
    KKIAPAY_PUBLIC_KEY  = "VOTRE_CLE_PUBLIQUE_SANDBOX"
    KKIAPAY_PRIVATE_KEY = "VOTRE_CLE_PRIVEE_SANDBOX"
    KKIAPAY_SECRET      = "VOTRE_SECRET_SANDBOX"
    KKIAPAY_SANDBOX     = True

    # Validation automatique
    GPS_TOLERANCE_KM    = 5.0   # Distance max autorisée du marché cible
    MIN_COLLECTES_VALID = 3     # Minimum de collectes pour finaliser
