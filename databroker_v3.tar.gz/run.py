from app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",  # Accessible depuis le réseau local
        port=5000,
        debug=True
    )
